<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GameLink extends Model
{
    use HasFactory;

    protected $fillable = [
        'game_id',
        'title',
        'url',
    ];


    public function game()
    {
        return $this->belongsTo(Game::class);
    }
    
}
