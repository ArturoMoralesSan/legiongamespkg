


<?php $__env->startSection('meta.title', 'Panel de administración' ); ?>
<?php $__env->startSection('meta.tab_title', 'Panel de administración | ' . config('app.name')); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Panel de administración
        </h1>
    </div>

    <div class="fluid-container">
        <p class="size-xl text-center">
            <strong>¡Bienvenida(o), <?php echo e($authUser->name); ?> <?php echo e($authUser->last_name); ?>!</strong>
        </p>

        <p class="text-center">
            Utiliza el menú para acceder a las áreas del sitio en donde puedes realizar cambios o consultar información.
        </p>

        <p class="text-center db-panel__advice">
            No olvides <strong>cerrar la sesión</strong> (en la parte superior derecha de esta pantalla) antes de cerrar la pestaña o si vas a estar alejado de tu computadora o dispositivo.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cluster\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>