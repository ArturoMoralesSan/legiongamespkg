

<?php $__env->startSection('title', config('app.name')); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url')); ?>
<?php $__env->startSection('class', 'home'); ?>

<?php $__env->startSection('content'); ?>
<section id="inicio" class="hero-home">

    <hero
        background-image="<?php echo e(asset('img/banner4.jpeg')); ?>"
        :is-parallax-active="true"
        hero-height="35vh"
    >
        <template slot="container">
            <div class="hero-grid-center">
                <div class="hero-left">
                    <h1 class="hero-title text-center">
                        JUEGOS
                    </h1>
                </div>
            </div>
        </template>
    </hero>
</section>

<section id="juegos" class="catalog-section section__xl">
    
    <div class="container">
        <game-catalog
            :platforms='<?php echo json_encode($platforms, 15, 512) ?>'
            :categories='<?php echo json_encode($categories, 15, 512) ?>'
            :initial-games='<?php echo json_encode($games, 15, 512) ?>'
        ></game-catalog>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nopay\resources\views/principal/juegos.blade.php ENDPATH**/ ?>