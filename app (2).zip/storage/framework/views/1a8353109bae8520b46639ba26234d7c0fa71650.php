


<?php $__env->startSection('title', 'Inventario'); ?>
<?php $__env->startSection('tab_title', 'Inventario | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Inventario.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Inventario
        </h1>

        <p class="dashboard-heading__caption">
            Hay <?php echo e($inventoriesItems->count()); ?> elementos registrados.
        </p>
    </div>

    <div class="fluid-container mb-16">

        <form-search 
                selected="<?php echo e(app('request')->input('search')); ?>"
            >
            <template slot="svg-search">
                <img class="search-form_icon" src="<?php echo e(url('img/svg/search.svg')); ?>" alt="">
            </template>
        </form-search>
        <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="db-panel">
            <h3 class="db-panel__title">
                Inventario
            </h3>

            <?php if(! $inventoriesItems->count()): ?>
                <p class="text-center py-1">
                    Por el momento no hay elementos registrados.
                </p>
            <?php else: ?>

                <resource-table :breakpoint="800" :model="<?php echo e($inventoriesItems); ?>" inline-template>
                    <table class="table size-caption mx-auto mb-16 md:table--responsive">
                        <thead>
                            <tr class="table-resource__headings">
                                <th>Producto</th>
                                <th>Cantidad mínima</th>
                                <th>Cantidad en existencia</th>
                                <th>Total</th>
                                <th class="pr-4">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="inventoryItem in resourceList" class="table-resource__row" :key="inventoryItem.id">
                                <td data-label="Producto:">
                                    {{ inventoryItem.product.name }}
                                </td>
                                <td data-label="Cantidad mínima:">
                                    {{ inventoryItem.quantity_min }}
                                </td>
                                <td data-label="Cantidad en existencia:">
                                    {{ inventoryItem.quantity }}
                                </td>
                                <td data-label="Total:">
                                    ${{ inventoryItem.total }}
                                </td>

                        
                                <td class="table-resource__actions" data-label="Acciones:">
                                    <a class="btn btn-nowrap btn--sm btn--blue table-resource__button mr-2" :href="$root.path + '/admin/inventario/' + inventoryItem.id + '/editar' ">
                                        <img class="svg-icon" src="<?php echo e(url('img/svg/edit.svg')); ?>">
                                        Editar
                                    </a>
                                    <delete-button class="btn--danger table-resource__button" :url="$root.path + '/admin/inventario/eliminar/' + inventoryItem.id"
                                        :resource-id="inventoryItem.id"
                                        :options="{ onDelete: onResourceDelete }"
                                    >
                                        <img class="svg-icon" src="<?php echo e(url('img/svg/trash.svg')); ?>">
                                        Eliminar
                                    </delete-button>
                                </td>
                            </tr>
                        </tbody>

                    </table>

                </resource-table>
                <?php echo $links; ?>

            <?php endif; ?>

        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/admin/inventario/index.blade.php ENDPATH**/ ?>