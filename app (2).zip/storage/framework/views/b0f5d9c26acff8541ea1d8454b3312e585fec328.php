<!doctype html>
<html class="no-js" lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="apple-mobile-web-app-capable" content="yes">

        <!-- DNS prefetch -->
        <link rel="dns-prefetch" href="//fonts.googleapis.com">

        <title><?php echo $__env->yieldContent('tab_title', config('app.name')); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <?php if(config('app.indexed') && view()->getSection('indexed') !== 'false'): ?>

            <?php if(view()->hasSection('canonical')): ?>
                <link rel="canonical" href="<?php echo $__env->yieldContent('canonical'); ?>">
            <?php endif; ?>

            <!-- Social networks -->
            <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>">
            <meta property="og:type" content="<?php echo $__env->yieldContent('type', 'website'); ?>">
            <meta property="og:url" content="<?php echo $__env->yieldContent('canonical'); ?>">
            <meta property="og:image" content="<?php echo $__env->yieldContent('img', url('/img/social-thumb.png')); ?>">
            <meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>">
            <meta property="og:site_name" content="<?php echo e(config('app.name')); ?>">

        <?php else: ?>

            <meta name="robots" content="noindex, nofollow">

        <?php endif; ?>

        <!-- Icons -->
        <?php echo $__env->make('layout.icons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- CSS -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i&display=swap" rel="stylesheet">
        <link href="<?php echo e(version('css/main.css')); ?>" rel="stylesheet">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    </head>
    <body class="<?php echo $__env->yieldContent('class'); ?>" data-root="<?php echo e(url('/')); ?>">
        <div id="app">
            <div id="bar" v-cloak>
                <?php echo $__env->make('layout.user-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php if(!Request::is('login')): ?>
                <?php echo $__env->make('layout.header', [
                    'activeLink' => view()->getSection('active_menu')
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            

            <main id="main" class="main" role="main">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <?php if(!Request::is('login')): ?>
                <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            

            <site-overlay></site-overlay>

        </div>
        <?php echo $__env->renderWhen(view()->hasSection('has_gallery'), 'components.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>

        <!-- Scripts -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="<?php echo e(version('js/vendor.js')); ?>"></script>
        <script src="<?php echo e(version('js/main.js')); ?>"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>
            AOS.init();
        </script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\cluster\resources\views/layout/master.blade.php ENDPATH**/ ?>