
<site-header
    :logo="'<?php echo e(url('img/logo.png')); ?>'"
    :uri="'<?php echo e(url('/')); ?>'"
    :breakpoint="760"
>
    <template slot="button-session">
        <div class="menu__container">
            <site-menu
                :breakpoint="760"
                :links='<?php echo json_encode($links, 15, 512) ?>'
                active-link="<?php echo e($activeLink); ?>"
            >
                <template slot="close">
                    Cerrar X
                </template>
            </site-menu>
            <!-- <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(url('login')); ?>" class="btn-login-menu">
                    <span>
                        <i class="fa-solid fa-user"></i>
                        Iniciar sesión
                    </span>
                </a>
            <?php endif; ?> -->
        </div>
    </template>
</site-header>


<?php /**PATH C:\laragon\www\nopay\resources\views/layout/header.blade.php ENDPATH**/ ?>