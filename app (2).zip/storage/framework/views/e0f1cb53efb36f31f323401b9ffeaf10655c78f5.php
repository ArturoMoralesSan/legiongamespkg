


<?php $__env->startSection('title', 'Usuarios'); ?>
<?php $__env->startSection('tab_title', 'Usuarios | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Lista de usuarios.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Usuarios
        </h1>

        <p class="dashboard-heading__caption">
            Hay <?php echo e($users->count()); ?> usuarios registrados.
        </p>
    </div>

    <div class="fluid-container mb-16">
        <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="db-panel">
            <h3 class="db-panel__title">
                Lista de usuarios
            </h3>

            <?php if(! $users->count()): ?>
                <p class="text-center py-1">
                    Por el momento no hay usuarios registrados.
                </p>
            <?php else: ?>

                <resource-table :breakpoint="800" :model="<?php echo e($users); ?>" inline-template>

                    <table class="table size-caption mx-auto mb-16 md:table--responsive">
                        <thead>
                            <tr class="table-resource__headings">
                                <th>Nombre completo</th>
                                <th>Correo Electrónico</th>
                                <th>Rol</th>
                                <th class="pr-4">Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr v-for="userItem in resourceList" class="table-resource__row" :key="userItem.id">
                                <td data-label="Folio:">
                                    <a class="" :href="$root.path + '/admin/usuarios/' + userItem.id + '/editar'">
                                        {{ userItem.name }} {{ userItem.last_name }}
                                    </a>
                                </td>
                                <td data-label="Correo electrónico:">
                                    {{ userItem.email }}
                                </td>
                                <td data-label="Roles:">
                                    {{ userItem.role.name }}
                                </td>
                                <td class="table-resource__actions" data-label="Acciones:">
                                    <a class="btn btn-nowrap btn--sm btn--blue table-resource__button mr-2" :href="$root.path + '/admin/usuarios/' + userItem.id + '/editar' ">
                                        <img class="svg-icon" src="<?php echo e(url('img/svg/edit.svg')); ?>">
                                        Editar
                                    </a>

                                    <delete-button class="btn--danger table-resource__button" v-if="userItem.id != <?php echo e(Auth::user()->id); ?>" :url="$root.path + '/admin/usuarios/eliminar/' + userItem.id"
                                        :resource-id="userItem.id"
                                        :options="{ onDelete: onResourceDelete }"
                                    >
                                        <img style="width: 15px;" class="svg-icon" src="<?php echo e(url('img/svg/trash.svg')); ?>">
                                        Eliminar
                                    </delete-button>
                                    


                                </td>
                            </tr>
                        </tbody>

                    </table>

                </resource-table>

            <?php endif; ?>

        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>