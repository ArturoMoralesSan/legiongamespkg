

<?php $__env->startSection('title', $game->title . ' | ' . config('app.name')); ?>
<?php $__env->startSection('description', $game->description ?? ''); ?>
<?php $__env->startSection('canonical', url('/juegos/' . $game->id)); ?>
<?php $__env->startSection('class', 'game-detail-page'); ?>

<?php $__env->startSection('content'); ?>



<hero
    background-image="<?php echo e(asset('img/banner4.jpeg')); ?>"
    :is-parallax-active="true"
    hero-height="35vh"
>
    <template slot="container">

        <div class="hero-grid-center">

            <div class="hero-left">

                <span class="game-detail-hero-label">
                    VIDEOJUEGO
                </span>

                <h1 class="hero-title text-center">
                    <?php echo e($game->title); ?>

                </h1>

            </div>

        </div>

    </template>
</hero>




<div class="container">

    <div class="row">

        

        <div class="md:col-2/3 col">

            

            <a
                href="<?php echo e(url('/juegos')); ?>"
                class="game-detail-back"
            >
                <i class="fa-solid fa-arrow-left"></i>
                Volver a juegos
            </a>


            

            <div class="game-detail-main">

                

                <div class="game-detail-cover">

                    <?php if($game->image): ?>

                        <img
                            src="<?php echo e(asset('uploads/games/' . $game->image)); ?>"
                            alt="<?php echo e($game->title); ?>"
                        >

                    <?php else: ?>

                        <div class="game-detail-placeholder">

                            <i class="fa-solid fa-gamepad"></i>

                        </div>

                    <?php endif; ?>

                </div>


                

                <div class="game-detail-info">

                    <span class="game-detail-label">
                        VIDEOJUEGO
                    </span>

                    <h2 class="game-detail-title">
                        <?php echo e($game->title); ?>

                    </h2>


                    

                    <?php if($game->platforms->count()): ?>

                        <div class="game-detail-section">

                            <span class="game-detail-section-title">
                                <i class="fa-solid fa-gamepad"></i>
                                Plataformas
                            </span>

                            <div class="game-detail-tags">

                                <?php $__currentLoopData = $game->platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <span class="game-detail-tag">
                                        <?php echo e($platform->name); ?>

                                    </span>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>

                    <?php endif; ?>


                    

                    <?php if($game->categories->count()): ?>

                        <div class="game-detail-section">

                            <span class="game-detail-section-title">
                                <i class="fa-solid fa-layer-group"></i>
                                Categorías
                            </span>

                            <div class="game-detail-tags">

                                <?php $__currentLoopData = $game->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <span class="game-detail-tag">
                                        <?php echo e($category->name); ?>

                                    </span>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>

                    <?php endif; ?>


                    

                    <?php if($game->size_mb): ?>

                        <div class="game-detail-data">

                            <span>
                                <i class="fa-solid fa-hard-drive"></i>
                                Tamaño
                            </span>

                            <strong>
                                <?php echo e($game->size_mb); ?>

                            </strong>

                        </div>

                    <?php endif; ?>


                    

                    <?php if(isset($game->year) && $game->year): ?>

                        <div class="game-detail-data">

                            <span>
                                <i class="fa-regular fa-calendar"></i>
                                Año
                            </span>

                            <strong>
                                <?php echo e($game->year); ?>

                            </strong>

                        </div>

                    <?php endif; ?>


                    

                    <?php if(isset($game->region) && $game->region): ?>

                        <div class="game-detail-data">

                            <span>
                                <i class="fa-solid fa-earth-americas"></i>
                                Región
                            </span>

                            <strong>
                                <?php echo e($game->region); ?>

                            </strong>

                        </div>

                    <?php endif; ?>

                </div>

            </div>


            

            <section class="game-detail-description">

                <h2>
                    <i class="fa-solid fa-align-left"></i>
                    Descripción
                </h2>


                <?php if($game->description): ?>
                    <div class="game-detail-description-text">
                        <?php echo $game->description; ?>

                    </div>
                <?php else: ?>
                    <p class="game-detail-empty">
                        No hay una descripción disponible para este juego.
                    </p>
                <?php endif; ?>


            </section>
            <section class="game-detail-description mb-4">

                <h2>
                    <i class="fa-solid fa-align-left"></i>
                    Descarga
                </h2>

                <div class="game-download-grid">

                    

                    <?php if($game->url_game): ?>

                        <a
                            href="<?php echo e(route('download.show', $game)); ?>"
                            class="download-btn"
                        >
                            <i class="fa-solid fa-download"></i>

                            <span>
                                Descargar juego
                            </span>
                        </a>

                    <?php endif; ?>


                    

                    <?php $__currentLoopData = $game->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <a
                            href="<?php echo e(route('download.link', [
                                'game' => $game->id,
                                'link' => $link->id
                            ])); ?>"
                            class="download-btn"
                        >

                            <i class="fa-solid fa-download"></i>

                            <span>
                                <?php echo e($link->title); ?>

                            </span>

                        </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </section>

        </div>


        

        <div class="md:col-1/3 col">

            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nopay\resources\views/principal/details.blade.php ENDPATH**/ ?>