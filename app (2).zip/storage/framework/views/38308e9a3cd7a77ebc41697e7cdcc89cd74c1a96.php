<div class="game-list">
    <div class="gamelist-header mb-3">
        <h6 class="gamelist--title mb-0">
            <i class="fa-solid fa-gamepad"></i>
            Últimos juegos añadidos
        </h6>

        <a href="<?php echo e(url('juegos')); ?>" class="see-more">
            Encontrar más
            <i class="fa-solid fa-arrow-right"></i>
        </a>
    </div>

    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="game-row">
             
             <div class="gamelist-container d-flex">
                <div class="game-image">
                <?php if($game->image): ?>
                    <img
                        src="<?php echo e(asset('uploads/games/' . $game->image)); ?>"
                        alt="<?php echo e($game->title); ?>"
                    >
                <?php else: ?>
                    <div class="game-image-placeholder">
                        <i class="fa-solid fa-gamepad"></i>
                    </div>
                <?php endif; ?>
                </div>
                
                <div class="game-main">
                    
                    <h4 class="game-title">
                        <?php echo e($game->title); ?>

                    </h4>
                    
                    <?php if($game->size_mb): ?>
                        <p class="game-size">
                            <?php echo e($game->size_mb); ?>

                        </p>
                    <?php endif; ?>
                    
                    <div class="game-tags tag-cloud">
                        
                        <?php if($game->platforms): ?>
                            <?php $__currentLoopData = $game->platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="tag small">
                                    <?php echo e($platform->name); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                        <?php if($game->categories): ?>
                            <?php $__currentLoopData = $game->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="tag small">
                                    <?php echo e($category->name); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
             </div>
            
            <div class="game-actions">
                <a
                    href="<?php echo e(route('games.show', $game->id)); ?>"
                    class="details-btn"
                    title="Ver detalles"
                    aria-label="Ver detalles"
                >
                    <i class="fa-solid fa-eye"></i>
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\nopay\resources\views/partials/gamelist.blade.php ENDPATH**/ ?>