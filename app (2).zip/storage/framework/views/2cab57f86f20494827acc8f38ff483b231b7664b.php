

<?php $__env->startSection('title', config('app.name')); ?>
<?php $__env->startSection('description', 'Iniciar-sesion.'); ?>
<?php $__env->startSection('canonical', config('app.url')); ?>
<?php $__env->startSection('class', 'home'); ?>
<?php $__env->startSection('content'); ?>
<section class="section section-login">
    
    <div class="container">
        <div class="login-form flex-col">
            <img class="login-image" src="<?php echo e(url('img/advantage-logo.png')); ?>" alt="">
            
            <form class="form-boxed" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <h1 class="h3 text-center">Iniciar Sesión</h1>
                <hr></hr>
                <div class="form-control mb-2">
                    <label for="username" class="col-md-4 col-form-label text-md-end"><?php echo e(__('User name')); ?></label>
                    <input id="username" type="text" class="form-field <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>

                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-control mb-2">
                    <label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>
                    <div style="position: relative; display: flex; align-items: center;">
                        <input id="password" type="password" class="form-field <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" style="padding-right: 40px;">

                        <button type="button" id="togglePassword" style="position: absolute; right: 10px; background: none; border: none; cursor: pointer;">
                            <img id="eyeClosedIcon" src="<?php echo e(asset('img/svg/eye-closed.svg')); ?>" width="24" height="24" alt="Cerrar ojo">
                            <img id="eyeOpenIcon" src="<?php echo e(asset('img/svg/eye-open.svg')); ?>" width="24" height="24" alt="Abrir ojo" style="display: none;">
                        </button>
                    </div>




                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row mb-4 justify-between items-center">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                        <label class="form-check-label text_remember" for="remember">
                            <?php echo e(__('Remember Me')); ?>

                        </label>
                    </div>
                    <p class="text_reset-pass m-0">
                        <a href="<?php echo e(route('password.request')); ?>">
                            Recuperar contraseña
                        </a>
                    </p>
                </div>
                <div class="text-center">
                    <button type="submit" type="button" class="btn btn--brand w-full">
                        <?php echo e(__('Login')); ?>

                    </button>
                </div>
                <!-- <div class="divider-form-login">
                    <span class="divider-form-login-span"> ó</span>
                </div>
                <div class="text-center pt-4">
                    <a href="<?php echo e(url('/login/google')); ?>" class="btn btn--google">
                        <div class="google-button__icon">
                            <img src="<?php echo e(url('img/google_icon.png')); ?>" alt="Google">
                        </div>
                    </a>
                </div> -->
            
                <p class="text_reset-pass m-0 mt-2">
                    <a href="<?php echo e(url('register')); ?>">
                        ¿Aún no tienes cuenta? Regístrate
                    </a>
                </p>
            </form>
        </div>
                
          
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.getElementById('togglePassword').addEventListener('click', function () {
            let passwordField = document.getElementById('password');
            let eyeClosed = document.getElementById('eyeClosedIcon');
            let eyeOpen = document.getElementById('eyeOpenIcon');

            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeClosed.style.display = "none";
                eyeOpen.style.display = "block";
            } else {
                passwordField.type = "password";
                eyeClosed.style.display = "block";
                eyeOpen.style.display = "none";
            }
        });
    </script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/auth/login.blade.php ENDPATH**/ ?>