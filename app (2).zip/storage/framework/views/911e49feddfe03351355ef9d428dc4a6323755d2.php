<?php if($paginator->hasPages()): ?>
<nav aria-label="Page navigation">
    <ul class="list-bare pagination d-flex items-center justify-center">
        <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled">
                <a class="page-link page-link--prev" href="#" tabindex="-1">Anterior</a>
            </li>
        <?php else: ?>
            <li class="page-item">
                <a class="page-link page-link--prev" href="<?php echo e($paginator->previousPageUrl()); ?>">Anterior</a>
            </li>
        <?php endif; ?>
    
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_string($element)): ?>
                <li class="page-item disabled"><?php echo e($element); ?></li>
            <?php endif; ?>
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="page-item active">
                            <a class="page-link"><?php echo e($page); ?></a>
                        </li>
                    <?php else: ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php if($paginator->hasMorePages()): ?>
            <li class="page-item">
                <a class="page-link page-link--next" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Siguiente</a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <a class="page-link page-link--next" href="#">Siguiente</a>
            </li>
        <?php endif; ?>
    </ul>
</nav>
<?php endif; ?><?php /**PATH D:\laragon\www\advantage\resources\views/layout/pagination.blade.php ENDPATH**/ ?>