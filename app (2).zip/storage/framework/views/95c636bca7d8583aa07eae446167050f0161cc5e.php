

<?php $__env->startSection('title', 'Juegos'); ?>
<?php $__env->startSection('tab_title', 'Juegos | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Lista de juegos.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Juegos
        </h1>

        <p class="dashboard-heading__caption">
            Hay <?php echo e($games->count()); ?> juegos registrados.
        </p>
    </div>

    <div class="fluid-container mb-16">

        <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <section class="db-panel">

            <h3 class="db-panel__title">
                Lista de juegos
            </h3>

            <?php if(! $games->count()): ?>

                <p class="text-center py-1">
                    Por el momento no hay juegos registrados.
                </p>

            <?php else: ?>

                <resource-table :breakpoint="800" :model="<?php echo e($games); ?>" inline-template>

                    <table class="table size-caption mx-auto mb-16 md:table--responsive">

                        <thead>
                            <tr class="table-resource__headings">
                                <th>Título</th>
                                <th>Tamaño</th>
                                <th>Plataformas</th>
                                <th>Categorías</th>
                                <th>Imagen</th>
                                <th class="pr-4">Acciones</th>
                            </tr>
                        </thead>

                        <tbody>

                            <tr
                                v-for="gameItem in resourceList"
                                class="table-resource__row"
                                :key="gameItem.id"
                            >
                                <td data-label="Título:">
                                    {{ gameItem.title }}
                                </td>

                                <td data-label="Tamaño:">
                                    {{ gameItem.size_mb }}
                                </td>

                                <td data-label="Plataformas:">
                                    <span
                                        v-for="platform in gameItem.platforms"
                                        :key="platform.id"
                                        class="mr-1"
                                    >
                                        {{ platform.name }}
                                    </span>
                                </td>
                                <td data-label="Categorías:">
                                    <span
                                        v-for="category in gameItem.categories"
                                        :key="category.id"
                                        class="mr-1"
                                    >
                                        {{ category.name }}
                                    </span>
                                </td>
                                <td data-label="Imagen:">
                                    <img :src="'/uploads/games/'+ gameItem.image" alt="" style="height: 60px;">
                                </td>

                                <td
                                    class="table-resource__actions"
                                    data-label="Acciones:"
                                >

                                    <a
                                        class="btn btn-nowrap btn--sm btn--blue table-resource__button mr-2"
                                        :href="$root.path + '/admin/juegos/' + gameItem.id + '/edit'"
                                    >
                                        <img
                                            class="svg-icon"
                                            src="<?php echo e(url('img/svg/edit.svg')); ?>"
                                        >
                                        Editar
                                    </a>

                                    <delete-button
                                        class="btn--danger table-resource__button"
                                        :url="$root.path + '/admin/juegos/' + gameItem.id"
                                        :resource-id="gameItem.id"
                                        :options="{ onDelete: onResourceDelete }"
                                    >
                                        <img
                                            class="svg-icon"
                                            src="<?php echo e(url('img/svg/trash.svg')); ?>"
                                        >
                                        Eliminar
                                    </delete-button>

                                </td>

                            </tr>

                        </tbody>

                    </table>

                </resource-table>

            <?php endif; ?>

        </section>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nopay\resources\views/admin/juegos/index.blade.php ENDPATH**/ ?>