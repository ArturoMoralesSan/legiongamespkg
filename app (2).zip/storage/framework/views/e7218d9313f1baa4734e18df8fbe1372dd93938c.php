<!doctype html>
    <html class="no-js" lang="es">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="cleartype" content="on">
        <meta name="apple-mobile-web-app-capable" content="yes">

        <!-- DNS prefetch -->
        <link rel="dns-prefetch" href="//fonts.googleapis.com">

        <title><?php echo $__env->yieldContent('meta.tab_title', config('app.name')); ?></title>
        <meta name="robots" content="noindex, nofollow">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <meta name="robots" content="noindex, nofollow">

        <!-- Icons -->
        <?php echo $__env->make('layout.icons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- CSS -->
        <link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,700i" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(version('css/dashboard.css')); ?>">
        <!-- PWA Manifest -->
        <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">
        <meta name="theme-color" content="#436eb3">
        

    </head>

    <body data-root="<?php echo e(url('/')); ?>" class="<?php echo $__env->yieldContent('css_classes'); ?>">
        <div id="dashboard" v-cloak>
            <?php echo $__env->make('layout.user-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="d-flex">
                <?php echo $__env->make('layout.dashboard-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <main id="main" class="db-main" :class="{ 'db-main--has-menu' : menuIsVisible }" role="main">

                    <?php echo $__env->yieldContent('content'); ?>

                </main>
            </div>
        </div>

        <?php echo $__env->renderWhen(view()->hasSection('has_gallery'), 'components.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>

        <!-- Scripts -->
        <script src="<?php echo e(version('js/vendor.js')); ?>"></script>
        <script src="<?php echo e(version('js/admin.js')); ?>"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\nopay\resources\views/layout/dashboard-master.blade.php ENDPATH**/ ?>