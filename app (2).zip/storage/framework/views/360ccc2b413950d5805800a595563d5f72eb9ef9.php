

<?php $__env->startSection('title', $platform->name); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url')); ?>
<?php $__env->startSection('class', 'platform-alphabet'); ?>

<?php $__env->startSection('content'); ?>

<section id="inicio" class="hero-home">

    <hero
        background-image="<?php echo e(asset('img/banner4.jpeg')); ?>"
        :is-parallax-active="true"
        hero-height="35vh"
    >
        <template slot="container">

            <div class="hero-grid-center">

                <div class="hero-left">

                    <h1 class="hero-title text-center">
                        <?php echo e(strtoupper($platform->name)); ?>

                    </h1>

                    <p class="text-center mt-2">
                        Selecciona una letra
                    </p>

                </div>

            </div>

        </template>
    </hero>

</section>


<section class="features-section">
    <div class="container">
        <div class="row">

            <div class="md:col-2/3 col">

                <div class="platforms-section">

                    <div class="platform-grid">

                        <?php $__currentLoopData = $alphabet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $count = $letters[$letter] ?? 0;
                            ?>

                            <div class="platform-card <?php echo e($count ? '' : 'disabled-card'); ?>">

                                
                                <?php if($count): ?>
                                    <a href="<?php echo e(url('/juegos?platform=' . $platform->id . '&letter=' . $letter)); ?>">
                                <?php endif; ?>


                                <div class="platform-icon image">

                                    <?php if(file_exists(public_path('img/alphabet/'.$letter.'.png'))): ?>

                                        <img
                                            src="<?php echo e(asset('img/alphabet/'.$letter.'.png')); ?>"
                                            class="letter-image"
                                            alt="<?php echo e($letter); ?>"
                                        >

                                    <?php else: ?>

                                        <span class="letter-placeholder">
                                            <?php echo e($letter); ?>

                                        </span>

                                    <?php endif; ?>

                                </div>

                                <div class="platform-count">
                                    <?php echo e(number_format($count)); ?> Juegos
                                </div>

                                <?php if($count): ?>
                                    </a>
                                <?php endif; ?>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

            </div>

            <div class="md:col-1/3 col">
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nopay\resources\views/principal/alfabeto.blade.php ENDPATH**/ ?>