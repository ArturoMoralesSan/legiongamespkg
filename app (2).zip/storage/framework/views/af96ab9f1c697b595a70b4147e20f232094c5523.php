


<?php $__env->startSection('title', config('app.name')); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url')); ?>
<?php $__env->startSection('class', 'news'); ?>
<?php $__env->startSection('content'); ?>
<section class="news-detail">
    <div class="news-detail__header">
        <div class="news-header__bg" style="background-image: url('<?php echo e(asset($news->image_url)); ?>');"></div>
        <div class="news-header__overlay"></div> <!-- overlay nuevo -->
    </div>

    <div class="container">
        <div class="news-detail__content">
            
            <!-- Fecha -->
            <div class="news-detail__date">
                <span class="news-detail__day"><?php echo e(\Carbon\Carbon::parse($news->dcreated_at)->format('d')); ?></span> 
                <span class="news-detail__month"><?php echo e(ucfirst(\Carbon\Carbon::parse($news->dcreated_at)->locale('es')->translatedFormat('F'))); ?></span> 
                <span class="news-detail__year"><?php echo e(\Carbon\Carbon::parse($news->dcreated_at)->format('Y')); ?></span>
            </div>

            <h1 class="news-detail__title"><?php echo e($news->title); ?></h1>

            <div class="news-detail__text">
                <?php echo $news->description; ?>

            </div>
            
            <div class="news-gallery">
                <img src="<?php echo e(asset($news->image_url)); ?>" alt="<?php echo e($news->image_url); ?>">
            </div>

        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cluster\resources\views/principal/news.blade.php ENDPATH**/ ?>