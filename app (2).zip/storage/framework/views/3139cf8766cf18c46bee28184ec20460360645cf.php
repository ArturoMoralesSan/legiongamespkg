<dashboard-menu v-cloak
    :is-loading="isLoading"
    :menu-is-visible="menuIsVisible"
    :menu="<?php echo e($dbMenu); ?>"
    @toggle-menu="toggleMenu"
>
</dashboard-menu><?php /**PATH C:\laragon\www\nopay\resources\views/layout/dashboard-menu.blade.php ENDPATH**/ ?>