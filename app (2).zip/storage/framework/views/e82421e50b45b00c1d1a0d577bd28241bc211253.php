

<?php $__env->startSection('title', 'Preparando descarga'); ?>

<?php $__env->startSection('content'); ?>

<section class="download-page">

    <div class="download-card">

        <div class="download-icon">

            <i class="fa-solid fa-download"></i>

        </div>

        <h1 class="download-card-title">

            <?php echo e($downloadTitle ?? $game->title); ?>


        </h1>

        <p class="text-center">

            Estamos preparando tu descarga.

        </p>

        <div class="countdown">

            <div class="timer-circle">

                <div class="timer-value">

                    <span id="timer">20</span>

                    <small>SEGUNDOS</small>

                </div>

            </div>

        </div>

        <div class="game-info">

            <div class="info-box">

                <strong>Juego</strong>

                <span>

                    <?php echo e($game->title); ?>


                </span>

            </div>

            <div class="info-box">

                <strong>Tamaño</strong>

                <span>

                    <?php echo e($game->size_mb ?? '--'); ?>


                </span>

            </div>

            <div class="info-box">

                <strong>Plataformas</strong>

                <div class="platforms">

                    <?php $__currentLoopData = $game->platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <span class="tag">

                            <?php echo e($platform->name); ?>


                        </span>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

            <div class="info-box">

                <strong>Categorías</strong>

                <div class="platforms">

                    <?php $__currentLoopData = $game->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <span class="tag">

                            <?php echo e($category->name); ?>


                        </span>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        </div>

        

        <a
            id="manualDownload"
            href="<?php echo e($downloadUrl); ?>"
            class="hero-btn"
            style="display:none"
        >

            <span>

                <i class="fa-solid fa-download"></i>

                Descargar ahora

            </span>

        </a>

    </div>

</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>

    let seconds = 20;

    const timer = document.getElementById('timer');

    const manualDownload = document.getElementById('manualDownload');

    const downloadUrl = <?php echo json_encode($downloadUrl, 15, 512) ?>;

    const interval = setInterval(function () {

        seconds--;

        timer.textContent = seconds;

        if (seconds <= 0) {

            clearInterval(interval);

            /*
             * Mostrar botón por si la redirección
             * tarda o el navegador la bloquea.
             */
            manualDownload.style.display = 'inline-flex';

            /*
             * Redirigir automáticamente.
             */
            window.location.href = downloadUrl;

        }

    }, 1000);

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nopay\resources\views/principal/await.blade.php ENDPATH**/ ?>