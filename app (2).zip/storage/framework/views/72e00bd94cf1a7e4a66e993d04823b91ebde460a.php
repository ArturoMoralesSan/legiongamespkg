


<?php $__env->startSection('title', 'Banners'); ?>
<?php $__env->startSection('tab_title', 'Banners | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Lista de banners.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Banners
        </h1>

        <p class="dashboard-heading__caption">
            Hay <?php echo e($banners->count()); ?> Banners registrados.
        </p>
    </div>

    <div class="fluid-container mb-16">
        <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="db-panel">
            <h3 class="db-panel__title">
                Lista de banners
            </h3>

            <?php if(! $banners->count()): ?>
                <p class="text-center py-1">
                    Por el momento no hay banners registrados.
                </p>
            <?php else: ?>

                <resource-table :breakpoint="800" :model="<?php echo e($banners); ?>" inline-template>
                    <table class="table size-caption mx-auto mb-16 md:table--responsive">
                        <thead>
                            <tr class="table-resource__headings">
                                <th>Titulo</th>
                                <th>Enlace</th>
                                <th>Descripción</th>
                                <th>Portada</th>
                                <th class="pr-4">Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr v-for="bannerItem in resourceList" class="table-resource__row" :key="bannerItem.id">
                                <td data-label="Titulo:">
                                    {{ bannerItem.title }}
                                </td>
                                <td data-label="Enlace:">
                                    {{ bannerItem.link }}
                                </td>
                                <td data-label="Descripción:" v-html="bannerItem.description">
                                </td>
                                <td data-label="Foto:">
                                    <img style="height:40px;" :src="$root.path +'/'+ bannerItem.image_url" v-if="bannerItem.image_url">
                                </td>
                                
                                <td class="table-resource__actions" data-label="Acciones:">
                                    <a class="btn btn-nowrap btn--sm btn--blue table-resource__button mr-2" :href="$root.path + '/admin/banners/' + bannerItem.id + '/editar' ">
                                        <img class="svg-icon" src="<?php echo e(url('img/svg/edit.svg')); ?>">
                                        Editar
                                    </a>
                                    <delete-button class="btn--danger table-resource__button" :url="$root.path + '/admin/banners/eliminar/' + bannerItem.id"
                                        :resource-id="bannerItem.id"
                                        :options="{ onDelete: onResourceDelete }"
                                    >
                                        <img class="svg-icon" src="<?php echo e(url('img/svg/trash.svg')); ?>">
                                        Eliminar
                                    </delete-button>
                                </td>
                            </tr>
                        </tbody>

                    </table>

                </resource-table>

            <?php endif; ?>

        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cluster\resources\views/admin/banners/index.blade.php ENDPATH**/ ?>