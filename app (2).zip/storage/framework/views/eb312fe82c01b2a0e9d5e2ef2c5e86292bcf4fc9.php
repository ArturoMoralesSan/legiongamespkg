


<?php $__env->startSection('title', 'Agregar cotización'); ?>
<?php $__env->startSection('tab_title', 'Agregar cotización | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Agregar cotización.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>

<section class="mb-16">
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Agregar venta
        </h1>
    </div>

    <div class="fluid-container mb-16">
        <p class="mb-12">
            <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <span class="color-link">«</span>
            <a href="<?php echo e(url('admin/ventas/')); ?>">Ver todas las ventas</a>
        </p>

        <product-registration-form
            action="<?php echo e(url('admin/ventas/crear')); ?>"
            :sale="<?php echo e(json_encode((object)[])); ?>"
            :users="<?php echo e($users); ?>"
            :cuts="<?php echo e($cuts); ?>"
            :types="<?php echo e($types); ?>"
            :product="30"
            :min-product="1"
            :products="<?php echo e($products); ?>"
            :assigned-products="[]"
            :product-data="[]"
        >
        </product-registration-form>
    
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/admin/ventas/crear.blade.php ENDPATH**/ ?>