


<?php $__env->startSection('title', 'Agregar rol'); ?>
<?php $__env->startSection('tab_title', 'Agregar rol | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Agregar rol.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>

<section class="mb-16">
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Agregar rol
        </h1>
    </div>

    <div class="fluid-container mb-16">
        <p class="mb-12">
            <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <span class="color-link">«</span>
            <a href="<?php echo e(url('admin/roles/')); ?>">Ver todos los roles</a>
        </p>

            <role-form action="<?php echo e(url('admin/roles/crear')); ?>"
                enctype="multipart/form-data"
                inline-template
                v-cloak
            >
                <form>
                    <section class="db-panel">
                        <h3 class="db-panel__title">
                            Datos del rol
                        </h3>

                        <div class="md:row">
                            <div class="md:col-2/3">
                                
                                <div class="form-control">
                                    <label for="name">Nombre</label>
                                    <text-field name="name" v-model="fields.name" maxlength="80" initial=""></text-field>
                                    <field-errors name="name"></field-errors>

                                </div>
                            </div>

                        </div>
                    </section>
                    <section class="db-panel">
                        <h3 class="db-panel__title">
                            Permisos
                        </h3>

                        <div class="md:row">
                            <div class="md:col">
                                <div class="permissions-container">
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="permission-item">
                                            <checkbox-field 
                                                v-model="fields.permissions_<?php echo e($permission->id); ?>" 
                                                name="permissions_<?php echo e($permission->id); ?>" 
                                            >
                                            </checkbox-field>
                                            <?php echo e($permission->name); ?>

                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

                                </div>
                            </div>
                        </div> 
                    </section>
                    <div class="text-center">
                        <form-button class="btn--success btn--wide">
                            Crear
                        </form-button>
                    </div>
                </form>
            </role-form>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/admin/roles/crear.blade.php ENDPATH**/ ?>