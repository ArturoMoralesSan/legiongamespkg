


<?php $__env->startSection('title', 'Editar banner'); ?>
<?php $__env->startSection('tab_title', 'Editar banner | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Editar banner.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>

<section class="mb-16">
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Editar banner
        </h1>
    </div>

    <div class="fluid-container mb-16">
        <p class="mb-12">
            <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <span class="color-link">«</span>
            <a href="<?php echo e(url('admin/banners/')); ?>">Ver todos los banners</a>
        </p>

            <base-form action="<?php echo e(url('admin/banners/'. $banner->id .'/actualizar')); ?>"
                method="put"
                enctype="multipart/form-data"
                inline-template
                v-cloak
            >
                <form>
                    <section class="db-panel">
                        <h3 class="db-panel__title">
                            Datos del banner
                        </h3>

                        <div class="md:row">
                            <div class="md:col-1/2">
                                
                                <div class="form-control">
                                    <label for="title">Titulo</label>
                                    <text-field name="title" v-model="fields.title" maxlength="80" initial="<?php echo e($banner->title); ?>"></text-field>
                                    <field-errors name="title"></field-errors>

                                </div>
                            </div>
                            <div class="md:col-1/2">
                                
                                <div class="form-control">
                                    <label for="link">Enlace</label>
                                    <text-field name="link" v-model="fields.link" maxlength="80" initial="<?php echo e($banner->link); ?>"></text-field>
                                    <field-errors name="link"></field-errors>

                                </div>
                            </div>
                        </div>
                        <div class="md:row"> 
                            <div class="md:col">
                                
                                <div class="form-control">
                                    <label for="description">Descripción</label>
                                    <text-area-tiny 
                                        name="description" 
                                        v-model="fields.description" 
                                        :initial-value="<?php echo e(json_encode($banner->description)); ?>">
                                    </text-area-tiny>
                                    <field-errors name="description"></field-errors>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section class="db-panel mb-16">
                        <h3 class="db-panel__title">
                            Portada
                        </h3>
                        <div class="md:row">
                            <div class="preview-aside">
                                <figure class="preview-aside__box preview-box">

                                    <img class="preview-box__img" src="<?php echo e(url($banner->image_url)); ?>" alt="" ref="thumb">                                  
                                    <figcaption class="preview-box__caption">
                                        Imagen actual
                                    </figcaption>
                                </figure>
                            </div>
                            <div class="md:col-2/3">
                                
                                <div class="form-control">
                                    <label for="cover">Agregar imagen</label>

                                    <file-field name="cover" v-model="fields.cover"></file-field>

                                    <field-errors name="cover"></field-errors>
                                    <ul id="cover-specs" class="description color-gray-darken-1">
                                        <li>
                                            Tamaño máximo: 1 MB.
                                        </li>
                                        <li>
                                            Sólo archivos con extensión jpeg, gif, png.
                                        </li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    </section>
                    <div class="text-center">
                        <form-button class="btn--blue--dashboard btn--wide">
                            Actualizar
                        </form-button>
                    </div>
                </form>
            </user-form>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cluster\resources\views/admin/banners/editar.blade.php ENDPATH**/ ?>