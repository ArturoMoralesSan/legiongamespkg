


<?php $__env->startSection('title', 'Agregar tipo de impresión'); ?>
<?php $__env->startSection('tab_title', 'Agregar tipo de impresión | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Agregar tipo de impresión'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>

<section class="mb-16">
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Agregar tipo de impresion
        </h1>
    </div>

    <div class="fluid-container mb-16">
        <p class="mb-12">
            <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <span class="color-link">«</span>
            <a href="<?php echo e(url('admin/tipos/')); ?>">Ver todos los tipos de impresión</a>
        </p>

            <base-form action="<?php echo e(url('admin/tipos/crear')); ?>"
                enctype="multipart/form-data"
                inline-template
                v-cloak
            >
                <form>
                    <section class="db-panel">
                        <h3 class="db-panel__title">
                            Datos del tipo de impresión
                        </h3>

                        <div class="md:row">
                            <div class="md:col-2/3">
                                
                                <div class="form-control">
                                    <label for="name">Nombre</label>
                                    <text-field name="name" v-model="fields.name" maxlength="80" initial=""></text-field>
                                    <field-errors name="name"></field-errors>

                                </div>
                            </div>

                        </div>
                    </section>
                    <div class="text-center">
                        <form-button class="btn--success btn--wide">
                            Crear
                        </form-button>
                    </div>
                </form>
            </base-form>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/admin/tipos/crear.blade.php ENDPATH**/ ?>