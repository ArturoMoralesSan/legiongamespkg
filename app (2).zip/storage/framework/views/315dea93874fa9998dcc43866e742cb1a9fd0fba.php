<div class="social-bar-container">
    <a style="margin-right: 5px;" href="https://www.facebook.com/unipolidgo"><img class="social-icon" src="<?php echo e(url('img/svg/facebook.svg')); ?>" alt=""></a>
    <a style="margin-right: 5px;" href="https://twitter.com/unipolidgo"><img class="social-icon" src="<?php echo e(url('img/svg/twitter.svg')); ?>" alt=""></a>
    <a href="https://www.instagram.com/unipolidgo/"><img class="social-icon" src="<?php echo e(url('img/svg/instagram.svg')); ?>" alt=""></a>
</div>
<site-header
    :logo="'<?php echo e(url('img/logo-imac.png')); ?>'"
    :uri="'<?php echo e(url('/')); ?>'"
    :breakpoint="760"
>
    <template slot="button-session">
        <a style="margin-right: 5px;" href="https://www.facebook.com/unipolidgo"><img class="social-icon" src="<?php echo e(url('img/svg/facebook.svg')); ?>" alt=""></a>
        <a style="margin-right: 5px;" href="https://twitter.com/unipolidgo"><img class="social-icon" src="<?php echo e(url('img/svg/twitter.svg')); ?>" alt=""></a>
        <a href="https://www.instagram.com/unipolidgo/"><img class="social-icon" src="<?php echo e(url('img/svg/instagram.svg')); ?>" alt=""></a>
    </template>
</site-header>


<?php /**PATH D:\laragon\www\advantage\resources\views/layout/header.blade.php ENDPATH**/ ?>