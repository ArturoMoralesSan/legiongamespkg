


<?php $__env->startSection('title', 'Orden de'); ?>
<?php $__env->startSection('tab_title', 'Orden de | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Orden de.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>

<section class="mb-16">
    <div class="dashboard-heading">
        <h1 class="dashboard-heading__title">
            Orden de trabajo
        </h1>
    </div>

    <div class="fluid-container mb-16">
        <p class="mb-12">
            <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <span class="color-link">«</span>
            <a href="<?php echo e(url('admin/ventas/')); ?>">Ver todas las ventas</a>
        </p>

        <section class="db-panel">
            <h3 class="db-panel__title">
                Datos de la orden
            </h3>

            <div class="md:row mb-2">
                <div class="md:col">
                    <table class="order-table__details">
                        <tbody>
                            <tr class="order-table__row">
                                <th class="order-table__cell--heading">ID de Venta:</th>
                                <td class="order-table__cell"><?php echo e($sale->id); ?></td>
                            </tr>
                            <tr class="order-table__row">
                                <th class="order-table__cell--heading">Cliente:</th>
                                <td class="order-table__cell"><?php echo e($sale->user->name); ?> <?php echo e($sale->user->last_name); ?></td>
                            <tr class="order-table__row">
                                <th class="order-table__cell--heading">Fecha de Creación:</th>
                                <td class="order-table__cell"><?php echo e($sale->created_at->format('d/m/Y')); ?></td>
                            </tr>
                            <tr class="order-table__row">
                                <th class="order-table__cell--heading">Estado:</th>
                                <td class="order-table__cell">
                                    <span class="badge badge-status badge-<?php echo e($sale->status); ?>">
                                        <?php echo e($status[$sale->status] ?? ucfirst($sale->status)); ?>

                                    </span>
                                </td>
                            </tr>
                            <tr class="order-table__row">
                                <th class="order-table__cell--heading">Subtotal:</th>
                                <td class="order-table__cell">$ <?php echo e(number_format($sale->total_sale_price, 4)); ?></td>
                            </tr>
                            <tr class="order-table__row">
                                <th class="order-table__cell--heading">IVA:</th>
                                <td class="order-table__cell">$ <?php echo e(number_format($sale->iva, 4)); ?></td>
                            </tr>
                            <tr class="order-table__row">
                                <th class="order-table__cell--heading">Total:</th>
                                <td class="order-table__cell">$ <?php echo e(number_format($sale->total_with_iva, 4)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </section>

        
        <div class="md:row mb-2">
            <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="md:col-auto">
                    <section class="db-panel">
                        <h3 class="db-panel__title">
                            <?php echo e($product->pivot->product_name); ?>

                        </h3>

                        <div class="order-table">
                            <div class="order-table__body">
                                <table class="order-table__details">
                                    <tbody>
                                        <tr class="order-table__row">
                                            <th class="order-table__cell--heading">Categoría:</th>
                                            <td class="order-table__cell">
                                                <?php echo e($product->type->name); ?>

                                            </td>
                                        </tr>
                                        <tr class="order-table__row">
                                            <th class="order-table__cell--heading">Producto:</th>
                                            <td class="order-table__cell">
                                                <?php echo e($product->name); ?>

                                            </td>
                                        </tr>
                                        <tr class="order-table__row">
                                            <th class="order-table__cell--heading">Acabado:</th>
                                            <td class="order-table__cell">
                                                <?php echo e($product->cut_name); ?>

                                            </td>
                                        </tr>
                                        <tr class="order-table__row">
                                            <th class="order-table__cell--heading">Ancho:</th>
                                            <td class="order-table__cell">
                                                <?php echo e($product->pivot->width); ?> cm
                                                
                                            </td>
                                        </tr>
                                        <tr class="order-table__row">
                                            <th class="order-table__cell--heading">Largo:</th>
                                            <td class="order-table__cell">
                                                <?php echo e($product->pivot->height); ?> cm
                                                
                                            </td>
                                        </tr>
                                        
                                        <tr class="order-table__row">
                                            <th class="order-table__cell--heading">Precio total:</th>
                                            <td class="order-table__cell">
                                                $ <?php echo e(number_format($product->pivot->sale_price, 2)); ?>

                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </section>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            
        </div>

        <?php if($sale->status != 'paid'): ?>
            <order-status-form 
                action="<?php echo e(url('admin/ventas/orden/'. $sale->id .'/actualizar')); ?>"
                method="PUT"
                :status="<?php echo e($status); ?>"
                :sale-data="<?php echo e($sale); ?>"
                :payment="3"
                :min-payment="0"
                :payments-data="<?php echo e($payments); ?>"
                :assigned-payments="<?php echo e($assigned_payments); ?>"
            >
            </order-status-form>
        <?php endif; ?>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/admin/ventas/orden.blade.php ENDPATH**/ ?>