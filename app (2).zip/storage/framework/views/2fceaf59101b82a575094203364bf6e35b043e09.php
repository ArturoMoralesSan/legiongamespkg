


<?php $__env->startSection('meta.title', 'Panel de administración' ); ?>
<?php $__env->startSection('meta.tab_title', 'Panel de administración | ' . config('app.name')); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-heading">
        <div class="md:row justify-between">
            <div class="md:col-1/2">
                <h1 class="dashboard-heading__title">
                    Panel de administración
                </h1>
            </div>
            <div class="md:col-1/2 d-flex items-center">
                <form-between-date-search
                        selectedstart="<?php echo e(app('request')->input('start_date')); ?>"
                        selectedend="<?php echo e(app('request')->input('end_date')); ?>"
                    >
                    <template slot="svg-search">
                        <img class="search-form_icon--55" src="<?php echo e(url('img/svg/search.svg')); ?>" alt="">
                    </template>
                </form-between-date-search>
            </div>
        </div>
        
        <div>
            
        </div>
    </div>

    <div class="fluid-container mb-16">
        <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="db-panel">
            <div class="row">
                <div class="column-statistics">
                   <strong>
                    Hoy <br>
                    <?php echo e($string_date); ?>

                   </strong> 
                </div>
                <div class="column-statistics">
                    <strong>$<?php echo e($ingresoNow); ?></strong> <br>
                    Ingresos
                </div>
                
                <div class="column-statistics mb-0">
                    <strong><?php echo e($salesNowCount); ?></strong> <br>
                    Ventas
                </div>
            </div>
        </section>
        <section class="db-panel">
            <h3 class="db-panel__title">
                Ingresos
            </h3>
            <canvas id="canvas" class="graph-statistics-income"></canvas>
        </section>
        <section class="db-panel">
            <div class="row">
                <div class="column-statistics-1-3 ">
                    <strong>$<?php echo e($ingreso); ?></strong> <br>
                    Ingresos
                </div>
                <div class="column-statistics-1-3 mb-0">
                    <strong> <?php echo e($salesCount); ?></strong> <br>
                    Ventas
                </div>
            </div>
        </section>
        <div class="md:row">
            <div class="md:col-1/2">
                <section class="db-panel">
                    <h3 class="db-panel__title">
                        Productos más populares
                    </h3>
                    <resource-table :breakpoint="800" :model="<?php echo e($productsCount); ?>" inline-template>

                        <table class="table size-caption mx-auto md:table--responsive">
                            <thead>
                                <tr class="table-resource__headings">
                                    <th>Producto</th>
                                    <th>Cantidad</th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr v-for="productItem in resourceList" class="table-resource__row" :key="productItem.id">
                                    <td data-label="Estudio:">
                                        {{ productItem.name }}
                                    </td>
                                    <td data-label="Cantidad:">
                                        {{ productItem.sales_count }}
                                    </td>
                                    
                                </tr>
                            </tbody>
                        </table>

                    </resource-table>
                </section>
            </div>
            <div class="md:col-1/2">
                <section class="db-panel">
                    <h3 class="db-panel__title">
                        Mejores clientes
                    </h3>
                    <resource-table :breakpoint="800" :model="<?php echo e($customerCount); ?>" inline-template>

                        <table class="table size-caption mx-auto md:table--responsive">
                            <thead>
                                <tr class="table-resource__headings">
                                    <th>Nombre</th>
                                    <th>Cantidad de compras</th>
                                    <th>Monto</th>
                                    <th>PDF</th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr v-for="customerItem in resourceList" class="table-resource__row" :key="customerItem.id">
                                    <td data-label="Gasto:">
                                        
                                        {{ customerItem.name }}
                                    </td>
                                    <td data-label="Cantidad:">
                                        {{ customerItem.sales_count }}
                                    </td>
                                    <td data-label="Cantidad:">
                                        $ {{ customerItem.total_sale_price }}
                                    </td>
                                    <td data-label="Reporte:">
                                    <link-pdf 
                                            :branchid="customerItem.id" 
                                            url="/admin/pdf-cliente/"
                                            startdate="<?php echo e(app('request')->input('start_date')); ?>"
                                            enddate="<?php echo e(app('request')->input('end_date')); ?>">
                                        </link-pdf>
                                    </td>
                            
                                </tr>
                            </tbody>
                        </table>

                    </resource-table>
                </section>
            </div>
        </div>
        
    </div>

    <script type="application/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.2.0/chart.js"></script>
    <script type="application/javascript">
        var amountPerDay = <?php echo $days; ?>;

        var lineChartData = {
            labels: Object.keys(amountPerDay),
            datasets: [{
                label: 'Total',
                fill: true,
                backgroundColor: ['rgba(64, 157, 205, 0.3)'],
                borderColor: '#36A2EB',
                data: Object.values(amountPerDay)
            }]
        };

        window.onload = function() {
            var ctx = document.getElementById("canvas").getContext("2d");
            window.myLine = new Chart(ctx, {
                type: 'line',
                data: lineChartData,
                options: {
                    responsive: true,                    title: {
                        display: true,
                        text: 'Total de Ingresos'
                    }
                }
            });
        };
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/admin/dashboard-admin.blade.php ENDPATH**/ ?>