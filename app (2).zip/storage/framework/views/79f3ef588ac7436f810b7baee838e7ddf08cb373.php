<?php if(Session::has('alert')): ?>
    <p class="alert alert--<?php echo e(Session::get('alert')['type'] ?? 'success'); ?> alert--has-icon animate-single-pop mb-8">
        <?php echo e(Session::get('alert')['message']); ?>

    </p>
<?php endif; ?>
<?php /**PATH C:\laragon\www\cluster\resources\views/components/alert.blade.php ENDPATH**/ ?>