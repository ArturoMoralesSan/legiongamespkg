<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cotización</title>
    <style>
        @page  {
            size: letter;
            margin-top:0px; /* Ajusta según sea necesario */
            margin-bottom: 0px;
        }

    
        .background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url("<?php echo e(public_path('img/atvantage_note.jpg')); ?>");
            background-size: cover;
            background-position: center;
            z-index: -1; /* Lo manda al fondo */
            opacity: 0.9; /* Ajusta la opacidad si el fondo es muy fuerte */
        }

        .contenido {
            position: relative;
            z-index: 1;
        }

        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            margin: 125px 0;
        }
        .info {
            display:block;
        }
        .id_cotización {
            float:right;
            text-align:right;
        }
        .header, .footer {
            width: 100%;
            border: 1px solid #000;
            padding: 10px;
            margin-bottom: 10px;
        }
        .header td, .footer td {
            padding: 5px;
        }
        .title {
            font-weight: bold;
            text-align: center;
            font-size: 14px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .table th, .table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
        }
        .table th {
            background:rgb(77, 77, 77);
            color: #fff;
        }
        .totals {
            width: 40%;
            float: right;
            margin-top: 10px;
        }
        .totals td {
            padding: 8px;
            border: 1px solid #000;
        }
    </style>
</head>
<body>
    <div class="background"></div>
    <div class="contenido">
            <div class="info">
                <table width="100%">
                    <tr>
                        <td><strong>Fecha:</strong> <?php echo e($sale->created_at->format('d/m/Y')); ?></td>
                        <td style="text-align: right;"><strong>ID de cotización:</strong> <?php echo e($sale->id); ?></td>
                    </tr>
                </table>
            </div>

            
            <table class="header">
                <tr>
                    <td><strong>Razón social:</strong> <?php echo e($sale->user->customer->business_name); ?></td>
                    <td><strong>Nombre comercial:</strong> <?php echo e($sale->user->customer->trade_name); ?> </td>
                    <td><strong>RFC:</strong> <?php echo e($sale->user->customer->rfc); ?></td>

                </tr>
                <tr>
                    <td><strong>Régimen Fiscal:</strong> <?php echo e($sale->user->customer->tax_regime); ?></td>
                    <td><strong>Contacto:</strong> <?php echo e($sale->user->customer->contact); ?></td>
                    <td><strong>Teléfono:</strong> <?php echo e($sale->user->customer->phone); ?></td>

                </tr>
                <tr>
                    <td><strong>Email:</strong> <?php echo e($sale->user->customer->email); ?></td>
                </tr>
                <tr>
                    <td><strong>Calle:</strong> <?php echo e($sale->user->customer->street); ?></td>
                    <td><strong>Número Ext.:</strong> <?php echo e($sale->user->customer->ext_number); ?></td>
                    <td><strong>Número Int.:</strong> <?php echo e($sale->user->customer->int_number); ?></td>
                </tr>
                <tr>
                    <td colspan="3"><strong>Entre Calles:</strong> <?php echo e($sale->user->customer->between_streets); ?> y <?php echo e($sale->user->customer->and_street); ?></td>
                </tr>
                <tr>
                    <td><strong>Colonia:</strong> <?php echo e($sale->user->customer->colony); ?></td>
                    <td><strong>Código Postal:</strong> <?php echo e($sale->user->customer->postal_code); ?></td>
                    <td><strong>Municipio:</strong> <?php echo e($sale->user->customer->municipality); ?></td>
                </tr>
                <tr>
                    <td><strong>Población:</strong> <?php echo e($sale->user->customer->population); ?></td>
                    <td><strong>Estado:</strong> <?php echo e($sale->user->customer->state); ?></td>
                    <td><strong>País:</strong> <?php echo e($sale->user->customer->country); ?></td>
                </tr>
            </table>
            
            <div class="title">Cotización de Productos</div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Producto</th>
                        <th>Categoría</th>
                        <th>Acabado</th>
                        <th>Ancho</th>
                        <th>Largo</th>
                        <th>Cant. utilizada</th>
                        <th>Importe</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->pivot->product_name); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->type->name); ?></td>
                            <td><?php echo e($product->cut_name); ?></td>
                            <td><?php echo e($product->pivot->width); ?> cm</td>
                            <td><?php echo e($product->pivot->height); ?> cm</td>
                            <td><?php echo e($product->pivot->quantity_product); ?></td>
                            <td>$<?php echo e(number_format($product->pivot->sale_price , 4)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
            <table class="totals">
                <tr>
                    <td>Subtotal</td>
                    <td style="text-align:right;">$<?php echo e(number_format($sale->total_sale_price, 2)); ?></td>
                </tr>
                <tr>
                    <td>IVA</td>
                    <td style="text-align:right;">$<?php echo e(number_format($sale->iva, 2)); ?></td>
                </tr>
                <tr>
                    <td><strong>Total</strong></td>
                    <td style="text-align:right;"><strong>$<?php echo e(number_format($sale->total_with_iva, 2)); ?></strong></td>
                </tr>
            </table>
            <div style="text-align: right; font-weight: bold; margin-top: 10px; clear: both;">
                <?php echo e($sale->letter); ?>

            </div>
            <?php if($sale->comment): ?>
                <table class="table" style="margin-top: 20px;">
                    <thead>
                        <tr>
                            <th>Comentarios</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($sale->comment); ?></td>
                        </tr>
                    </tbody>
                </table>
            <?php endif; ?>
    </div>
</body>
</html><?php /**PATH D:\laragon\www\advantage\resources\views/admin/pdf/notesale.blade.php ENDPATH**/ ?>