
<site-header
    :logo="'<?php echo e(url('img/cluster-minero-logo.png')); ?>'"
    :uri="'<?php echo e(url('/')); ?>'"
    :breakpoint="760"
>
    <template slot="button-session">
        <div class="menu__container">
            <site-menu
            :breakpoint="760"
            :links="{
                'Inicio': '/#inicio',
                'Acerca de': '/#acerca',
                'Servicios': '/#servicios',
                'Empresas': '/#empresas',
                'Proveedores': '/#proveedores',
                'Plataforma': '/#plataforma',
                'Directorio': '/#directorio',
                'Noticias': '/#news',
                'Contacto': '/#contacto',
            }"
            active-link="<?php echo e($activeLink); ?>"
            >
                <template slot="close">
                    Cerrar X
                </template>
            </site-menu>
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(url('login')); ?>" class="btn btn--outline-primary btn-login-menu">
                    <img class="img-user-login" src="<?php echo e(url('img/header/users.svg')); ?>">
                    Ingresar
                </a>
            <?php endif; ?>
        </div>
    </template>
</site-header>


<?php /**PATH C:\laragon\www\cluster\resources\views/layout/header.blade.php ENDPATH**/ ?>