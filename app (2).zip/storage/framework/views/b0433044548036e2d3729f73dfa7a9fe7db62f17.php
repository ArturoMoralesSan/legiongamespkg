

<?php $__env->startSection('title', config('app.name')); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url')); ?>
<?php $__env->startSection('class', 'home'); ?>

<?php $__env->startSection('content'); ?>


<section id="inicio" class="hero-home">

    <hero
        background-image="<?php echo e(asset('img/banner4.jpeg')); ?>"
        :is-parallax-active="true"
        hero-height="35vh"
    >
        <template slot="container">
            <div class="hero-grid-center">
                <div class="hero-left">
                    <h1 class="hero-title text-center">
                        CATEGORIAS
                    </h1>
                </div>
            </div>
        </template>
    </hero>
</section>
<section class="features-section">
    <div class="container">
        <div class="row">
            <div class="md:col-2/3 col">
                <div class="platforms-section">

                    <div class="platform-grid">

                        <?php $__currentLoopData = $categoriesgames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="platform-card">
                                <div class="platform-icon">
                                    <i class="fa-solid fa-table-list"></i>
                                </div>

                                <div class="platform-name">
                                    <?php echo e($category->name); ?>

                                </div>

                                <div class="platform-count">
                                    <a href="<?php echo e(url('/juegos?category=' . $category->id)); ?>">
                                        <?php echo e(number_format($category->games_count)); ?>

                                        Juegos
                                    </a>
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>
            </div>
            
            <div class="md:col-1/3 col">
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nopay\resources\views/principal/categories.blade.php ENDPATH**/ ?>