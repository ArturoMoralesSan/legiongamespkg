<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('img/logo.jpeg')); ?>">
<link rel="icon" type="image/png" sizes="32x32" href=" <?php echo e(asset('img/logo.jpeg')); ?>">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/logo.jpeg')); ?>"><?php /**PATH C:\laragon\www\nopay\resources\views/layout/icons.blade.php ENDPATH**/ ?>