

<?php $__env->startSection('title', config('app.name')); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url')); ?>
<?php $__env->startSection('class', 'home'); ?>

<?php $__env->startSection('content'); ?>


<section id="inicio" class="hero-home">

    <hero
    background-image="<?php echo e(asset('img/banner1.jpeg')); ?>"
    :is-parallax-active="true"
    hero-height="70vh"
>
    <template slot="container">
        <div class="hero-grid">
            <div class="hero-left">
                <span class="hero-subtitle">
                    BIENVENIDO A
                </span>

                <h1 class="hero-title">
                    LEGIONGAMESPKG
                </h1>

                <p class="hero-description">
                    Tu mejor fuente de juegos para Playstation.
                    Descargas directas, rápidas y sin límites.
                </p>

                <div class="hero-search">
                    <form action="<?php echo e(url('juegos')); ?>" method="GET" class="hero-search-form">

                        <i class="fa-solid fa-magnifying-glass"></i>

                        <input
                            type="text"
                            name="search"
                            placeholder="Buscar juegos..."
                            autocomplete="off"
                        >

                        <button type="submit">
                            Buscar
                        </button>

                    </form>
                </div>
            </div>
        </div>
    </template>
</hero>
</section>


<!-- <section class="features-section">
    <div class="container">
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon"><i class="fa-solid fa-download"></i></div>
                <div>
                    <h4>Descargas Directas</h4>
                    <p>Enlaces rápidos y seguros</p>
                </div>
            </div>

            <div class="feature-card">
                <div class="feature-icon"><i class="fa-solid fa-shield"></i></div>
                <div>
                    <h4>Sin Límites</h4>
                    <p>Descarga sin restricciones</p>
                </div>
            </div>

            <div class="feature-card">
                <div class="feature-icon"><i class="fa-solid fa-gamepad"></i></div>

                <div>
                    <h4>Juegos Optimizados</h4>
                    <p>Listos para Xbox 360 RGH</p>
                </div>
            </div>

            <div class="feature-card">
                <div class="feature-icon"><i class="fa-solid fa-bolt"></i></div>
                <div>
                    <h4>Actualizaciones</h4>
                    <p>DLCs, parches y más</p>
                </div>
            </div>

        </div>

    </div>

</section> -->
<section class="features-section">
    <div class="container">
        <h6 class="gamelist--title  text-center mb-4">
            Plataformas NPS
        </h6>
        <div class="platform-grid">

            <?php $__currentLoopData = $platformsgames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="platform-card">

                    <div class="platform-icon">
                        <?php switch(strtolower($platform->name)):

                            case ('psp'): ?>
                                <i class="fa-solid fa-mobile-screen"></i>
                                <?php break; ?>

                            <?php case ('psvita'): ?>
                            <?php case ('ps vita'): ?>
                                <i class="fa-solid fa-gamepad"></i>
                                <?php break; ?>

                            <?php case ('psx'): ?>
                            <?php case ('ps1'): ?>
                                <i class="fa-solid fa-compact-disc"></i>
                                <?php break; ?>

                            <?php case ('ps2'): ?>
                                <i class="fa-solid fa-compact-disc"></i>
                                <?php break; ?>

                            <?php case ('ps3'): ?>
                                <i class="fa-solid fa-gamepad"></i>
                                <?php break; ?>

                            <?php case ('ps4'): ?>
                                <i class="fa-solid fa-gamepad"></i>
                                <?php break; ?>

                            <?php default: ?>
                                <i class="fa-solid fa-tv"></i>
                        <?php endswitch; ?>
                    </div>

                    <div class="platform-name">
                        <?php echo e($platform->name); ?>

                    </div>

                    <div class="platform-count">
                        <a href="<?php echo e(url('/plataforma/' . $platform->id .'/alfabeto')); ?>">
                            <?php echo e(number_format($platform->games_count)); ?>

                            Juegos
                        </a>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<section class="features-section">
    <div class="container">
        <div class="row">
            
            <div class="md:col-2/3 col">
                <?php echo $__env->make('partials.gamelist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            
            <div class="md:col-1/3 col">
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nopay\resources\views/principal/home.blade.php ENDPATH**/ ?>