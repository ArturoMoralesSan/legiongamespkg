


<?php $__env->startSection('title', 'Agregar usuarios'); ?>
<?php $__env->startSection('tab_title', 'Agregar usuarios | ' . config('app.name')); ?>
<?php $__env->startSection('description', 'Agregar usuarios.'); ?>
<?php $__env->startSection('css_classes', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <section class="mb-16">
        <div class="dashboard-heading">
            <h1 class="dashboard-heading__title">
                Agregar cliente
            </h1>
        </div>

        <div class="fluid-container mb-16">
            <p class="mb-12">
                <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <span class="color-link">«</span>
                <a href="<?php echo e(url('admin/clientes/')); ?>">Ver todos los clientes</a>
            </p>

            <customer-form
                action="<?php echo e(url('admin/clientes/crear')); ?>"
                :user="{}"
            >
            </customer-form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\advantage\resources\views/admin/clientes/crear.blade.php ENDPATH**/ ?>